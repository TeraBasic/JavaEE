package com.example.demoSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSqlApplication.class, args);
	}

}
