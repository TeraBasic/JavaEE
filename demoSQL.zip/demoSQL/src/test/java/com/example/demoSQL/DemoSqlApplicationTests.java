package com.example.demoSQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
